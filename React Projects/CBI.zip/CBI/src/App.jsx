import { LoginPage } from "./Pages/LoginPage";
// import { Index } from "./Routing/Index";

// import { Logout } from "./Pages/Popups/Logout";

export default function App() {
  return (
    <div>
      <LoginPage />
      {/* <Index /> */}
      {/* <Logout/> */}
    </div>
  );
}
